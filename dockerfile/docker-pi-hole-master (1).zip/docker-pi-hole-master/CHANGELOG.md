# Docker Pi-Hole changelog

Notes about releases will be documented on [docker-pi-hole's github releases page](https://github.com/pi-hole/docker-pi-hole/releases).  Breaking changes will be copied to the top of the docker repo's README file to assist with common upgrade issues.

See the [Pi-hole releases](https://github.com/pi-hole/pi-hole/releases) for details on updates unrelated to docker image releases
